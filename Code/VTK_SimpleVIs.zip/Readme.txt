Group members: Meraj Khan, Xiaotong Liu

The input test file is "../data/cylinder.vtk", and the selected attribute is "Pres"

Four files correspond to four visualisations respectively. Simply run each using python.