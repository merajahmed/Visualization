Group members: Meraj Khan, Xiaotong Liu

The input test file is tos_O1_2001-2002.nc

Command to run the main program: python Resampler.py