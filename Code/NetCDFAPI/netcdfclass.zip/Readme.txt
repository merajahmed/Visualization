Group members: Meraj Khan, Xiaotong Liu

Command to run the main program: python main.py

Note: python 2.7 is used in both assignments