Group members: Meraj Khan, Xiaotong Liu

The input test file is tornado.nc

Command to run the main program: python slicer.py